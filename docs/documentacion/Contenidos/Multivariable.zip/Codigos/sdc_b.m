
% Definiciones y parámetros
dt = 0.001;
t = 0:dt:10;

% Matrices de espacio de estados
A = [0 1 0; -78.8716 -1.3195 58.8139; 0 0 -1.5151];
B = [0; 0.529396; 0.026515];
C = [1 0 0];
D = 0;

% Condiciones iniciales
x0 = [0; 0; 0];  

% Calcular v_i0
v_i0 = -((pi / 6) / (C * inv(A) * B));

% Función r(t)
r_t = (t - 1) .* (t >= 1) - (t - 4) .* (t >= 4);

% Entrada v(t)
v_t = v_i0 * r_t / 3;

% Predefinir variables para la simulación
x = zeros(3, length(t));
y = zeros(size(t));
psi_dot = zeros(size(t));
omega = zeros(size(t));

% Función para calcular dx/dt
dxdt = @(x, v) A * x + B * v;

% Simulación paso a paso con Runge-Kutta de 4to orden
for i = 1:length(t)
    if i == 1
        x(:, i) = x0;
    else
        % Runge-Kutta de 4 orden
        k1 = dt * dxdt(x(:, i-1), v_t(i-1));
        k2 = dt * dxdt(x(:, i-1) + 0.5 * k1, v_t(i-1));
        k3 = dt * dxdt(x(:, i-1) + 0.5 * k2, v_t(i-1));
        k4 = dt * dxdt(x(:, i-1) + k3, v_t(i-1));
        
        x(:, i) = x(:, i-1) + (k1 + 2*k2 + 2*k3 + k4) / 6;
    end
    
    % Salida del sistema
    y(i) = C * x(:, i);         % Ángulo psi(t)
    psi_dot(i) = x(2, i);       % Derivada de psi (velocidad angular)
    omega(i) = x(3, i);    % Velocidad de rotación 
end


% Convertir ángulo a grados
psi_grados = y * 180 / pi;
omega_rpm=omega*60/(2*pi);
dark_purple = [0.5, 0, 0.5]; 
% Graficar resultados
figure;
subplot(4,1,1);
plot(t, v_t,'g');
title('Entrada vi(t)');
xlabel('Tiempo (s)');
ylabel('vi(t)');
subplot(4,1,2);
hold on;
plot(t, psi_grados, 'r');
title('Ángulo $\psi(t)$ (grados)', 'Interpreter', 'latex');
xlabel('Tiempo (s)');
ylabel('\psi(t) [grados]', 'Interpreter', 'latex');

subplot(4,1,3);
plot(t, psi_dot, 'r');
title('Velocidad angular $\dot{\psi}(t)$', 'Interpreter', 'latex');
xlabel('Tiempo (s)');
ylabel('\dot{\psi}(t) [rad/s]', 'Interpreter', 'latex');

subplot(4,1,4);
plot(t, omega_rpm, 'Color', dark_purple);
title('Velocidad angular $\omega(t)$ (rpm)', 'Interpreter', 'latex');
xlabel('Tiempo (s)');
ylabel('\omega(t) [rpm]', 'Interpreter', 'latex');

figure;
plot(t, psi_grados, 'Color', dark_purple);
title('Ángulo $\psi(t)$ (grados) con Runge-Kutta', 'Interpreter', 'latex');
xlabel('Tiempo (s)');
ylabel('\psi(t) [grados]', 'Interpreter', 'latex');

