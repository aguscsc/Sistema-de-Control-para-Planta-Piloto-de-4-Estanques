%Ejercicio g)
clc
clear
close all

% PERIODO DISCRETO EN MILISEGUNDOS
T=200*10^(-3); 

% VECTOR TIEMPO
td=0:T:10; 

%GANANCIAS
kc=4*10^(-3);
ka=100;
kst=180/pi;

% MATRICES DE ESTADO DISCRETAS LAZO CERRADO CON RETARDO
Alcd=[-0.1106 0.0970 0.7400 0.0090*ka;-7.6488 -0.2385 4.5825 0.0713*ka;0 0 0.7386 0.0047*ka;-kst*kc 0 0 0];

Blcd=[0;0;0;kc];

Clcd=[1 0 0 0];
Clcd2=[0 1 0 0];
Clcd3=[0 0 1 0];
Clcd4=[0 0 0 1];

Dlcd=[0];

%CREACION DE LA SEÑAL DE REFERENCIA
unitstep1 = td>=1;
ramp1 = (td-1).*unitstep1; %señal rampa desplazada 1 hacia la derecha

unitstep2 = td>=4;
ramp2 = (td-4).*unitstep2; %señal rampa desplazada 4 hacia la derecha

Ango=pi/6; %angulo en estado estacionario
Angd=Ango*kst*(ramp1-ramp2)*(1/3); %angulo de referencia"

%FUNCIONES DE TRANSFERENCIA (Z), NUMERADORES Y DENOMINADORES 
[num,den]=ss2tf(Alcd,Blcd,Clcd,Dlcd);
[num2,den2]=ss2tf(Alcd,Blcd,Clcd2,Dlcd);
[num3,den3]=ss2tf(Alcd,Blcd,Clcd3,Dlcd);
[num4,den4]=ss2tf(Alcd,Blcd,Clcd4,Dlcd);

%RESPUESTA DE LAS FUNCIONES DE TRANSFERENCIA ANTE UNA ENTRADA Angd
Angulo=filter(num,den,Angd); %respuesta de H(z) causado por el angulo de referencia
VelocidadAngular1=filter(num2,den2,Angd);
VelocidadAngular2=filter(num3,den3,Angd);
EntradaW=filter(num4,den4,Angd);

%GRAFICAS
figure
subplot(6,1,1)
stem(td,EntradaW*ka,'.g')
title('Entrada vi(kT)')
xlabel('Tiempo (s)')
ylabel('vi(kT) [V]')

subplot(6,1,2)
stem(td,EntradaW,'.k')
title('Entrada del Actuador w(kT)')
xlabel('Tiempo (s)')
ylabel('w(kT)')

subplot(6,1,3)
stem(td,Angulo*(180/pi),'or','LineWidth',3)
hold on
stem(td,Angd,'.g')
title('Ángulo $\psi$(kT) (grados)')
xlabel('Tiempo (s)')
ylabel('$\psi$(kT) [grados]')
legend('Angulo Real','Referencia')

subplot(6,1,4)
stem(td,VelocidadAngular1,'.r')
title('Velocidad angular $\cdot{\psi}$(kT)')
xlabel('Tiempo (s)')
ylabel('$\cdot{\psi}$(kT) [rad/s]')

subplot(6,1,5)
stem(td,VelocidadAngular2*(60/(2*pi)),'.m')
title('Velocidad angular $\omega$(kT) (rpm)')
xlabel('Tiempo (s)')
ylabel('$\omega$(kT) [rpm]')

subplot(6,1,6)
stem(td,Angd-(Angulo*kst),'.y')
title('Error ($\psi$d(kT)-$\psi$(kT)*kst)')
xlabel('Tiempo (s)')
ylabel('e(kT)')

%VALORES PROPIOS DEL SISTEMA
ValoresPropiosdeAlcd=eig(Alcd)

% GRAFICA DE POLOS 'X' Y CEROS 'O'
sys = idss(Alcd,Blcd,Clcd,Dlcd,'Ts',T);
figure
pzmap(sys)

%ejercicio g) segunda parte "Como afectaria nuestra entrada u(kT) con retentor a un sistema de tiempo continuo"

%TIEMPO CONTINUO
tc = 0:0.001:10;

%VOLTAJE DISCRETO QUE SALE DEL ACTUADOR u(kT)
Vi=EntradaW*ka;

% FUNCION DE RETENTOR PARA EL VOLTAJE
FuncionRetentor=@(t) Vi(floor(t/T)+1);

% VOLTAJE CON RETENTOR 
Vir=FuncionRetentor(tc);

%MATRICES DE ESTADO DEL PROCESO SIN REALIMENTACION
A=[0 1 0;-78.872 -1.319 58.814;0 0 -1.515];

B=[0;0.529;0.027];

C=[1 0 0];
C2=[0 1 0];
C3=[0 0 1];

D=0;

%CONDICIONES INICIALES
x0=[0;0;0];

%FUNCION PARA EVALUAR LAS ECUACIONES DE ESTADO 
EcEstado=@(t,x) A*[x(1);x(2);x(3)] + B.*FuncionRetentor(t);

%COMANDO ODE PARA SOLUCIONAR EL SISTEMA DE ECUACIONES DIFERENCIALES
[tode,y]=ode45(EcEstado,tc,x0);

%ASIGNACION DE LOS RESULTADOS DE LAS 3 SALIDAS "y" QUE ESTAN AGRUPADAS
%EN COLUMNA
AnguloC=y(:,1);
VelocidadAngular1C=y(:,2);
VelocidadAngular2C=y(:,3);

%GRAFICAS
figure
subplot(3,1,1)
stem(td,Angd,'.g')
title('Ángulo deseado $\psi$d(kT) (grados)')
xlabel('Tiempo (s)')
ylabel('$\psi$d(kT) [grados]')
grid on

subplot(3,1,2)
stem(td,EntradaW,'.k')
title('Entrada del Actuador w(kT)')
xlabel('Tiempo (s)')
ylabel('w(kT)')
grid on

subplot(3,1,3)
plot(tc,Vir,'r','LineWidth',2)
hold on
stem(td,EntradaW*ka,'.g')
title('Entradas vi')
xlabel('Tiempo (s)')
ylabel('vi(kT) [V]')
legend('vi(kT) con retentor','vi(kT) discreto "u(kT)"')
grid on

figure
subplot(3,1,1)
plot(tode,AnguloC*(180/pi))
hold on
stem(td,Angulo*(180/pi),'.r')
title('Ángulos $\psi$ (grados)')
xlabel('Tiempo (s)')
ylabel('$\psi$ [grados]')
legend('$\psi$(t) en tiempo continuo','$\psi$(kT) en tiempo discreto')
grid on

subplot(3,1,2)
plot(tode,VelocidadAngular1C,'LineWidth',2)
hold on
stem(td,VelocidadAngular1,'.r')
title('Velocidades angulares d$\psi$/dt')
xlabel('Tiempo (s)')
ylabel('d$\psi$/dt [rad/s]')
legend('d$\psi$/dt(t) en tiempo continuo','d$\psi$/dt(kT) en tiempo discreto')
grid on

subplot(3,1,3)
plot(tode,VelocidadAngular2C*(60/(2*pi)),'LineWidth',2)
hold on
stem(td,VelocidadAngular2*(60/(2*pi)),'.m')
title('Velocidades angulares $\omega$ (rpm)')
xlabel('Tiempo (s)')
ylabel('$\omega$ [rpm]')
legend('$\omega$(t) en tiempo continuo','$\omega$(kT) en tiempo discreto')
grid on

