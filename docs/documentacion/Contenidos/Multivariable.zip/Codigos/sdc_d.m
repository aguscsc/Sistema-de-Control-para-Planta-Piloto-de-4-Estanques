close all
clear
% Definiciones y parámetros
dt = 0.001;
t = 0:dt:10;

% Matrices de espacio de estados
A = [0 1 0; -78.8716 -1.3195 58.8139; 0 0 -1.5151];
B = [0; 0.529396; 0.026515];
C = [1 0 0];
D = 0;

% Ganancias del sistema
Kc = 0.022246464467246884698;     % Ganancia del controlador
Ka = 100;                         % Ganancia del actuador
Kst = 180/pi;                     % Ganancia del sensor transmisor

% Condiciones iniciales
x0 = [0; 0; 0];  

% Función r(t)
r_t = (t - 1) .* (t >= 1) - (t - 4) .* (t >= 4);

% Referencia psi_d
psi_d = (pi / 6) * Kst * r_t / 3;

% Predefinir variables para la simulación
x = zeros(3, length(t));
y = zeros(size(t));           % Ángulo psi(t)
psi_dot = zeros(size(t));     % Velocidad angular
omega = zeros(size(t));       % Velocidad de rotación en rpm
error = zeros(size(t));       % Error de control
v_t = zeros(size(t));         % Entrada controlada v(t)
w_actuator = zeros(size(t));  % Señal del actuador



% Función para calcular dx/dt
dxdt = @(x, v) A * x + B * v;

% Simulación paso a paso con control de lazo cerrado
for i = 1:length(t)
    if i == 1
        x(:, i) = x0;
    else
        % Control proporcional
        error(i) = psi_d(i) - Kst * y(i-1);  % Error de control con ganancia del sensor
        w_actuator(i) = Kc * error(i);       % Señal del actuador
        v_t(i) = Ka * w_actuator(i);         % Señal de control v(t)
        if v_t(i) < 0
            v_t(i) = 0;
        end
        
        % Runge-Kutta de 4 orden para la integración de los estados
        k1 = dt * dxdt(x(:, i-1), v_t(i-1));
        k2 = dt * dxdt(x(:, i-1) + 0.5 * k1, v_t(i-1));
        k3 = dt * dxdt(x(:, i-1) + 0.5 * k2, v_t(i-1));
        k4 = dt * dxdt(x(:, i-1) + k3, v_t(i-1));
        
        x(:, i) = x(:, i-1) + (k1 + 2*k2 + 2*k3 + k4) / 6;
    end
    
    % Salida del sistema
    y(i) = C * x(:, i);         % Ángulo psi(t)
    psi_dot(i) = x(2, i);       % Derivada de psi (velocidad angular)
    omega(i) = x(3, i);    % Velocidad de rotación 
end

% Convertir ángulo a grados
psi_degrees = y * 180 / pi;
omega_rpm=omega*60/(2*pi);

dark_purple = [0.5, 0, 0.5]; 
figure;

subplot(3,1,1);
plot(t, v_t,'g');
title('Entrada vi(t)');
xlabel('Tiempo (s)');
ylabel('vi(t)');

subplot(3,1,2);
hold on;
plot(t, psi_d, '--', 'DisplayName', 'Referencia $\psi_d(t)$');
plot(t, psi_degrees,'r', 'DisplayName', 'Ángulo $\psi(t)$');
title('Ángulo $\psi(t)$ (grados) vs Referencia');
xlabel('Tiempo (s)');
ylabel('$\psi(t)$ [grados]');
legend;

subplot(3,1,3);
plot(t, psi_dot,'r');
title('Velocidad angular $\dot{\psi}$');
xlabel('Tiempo (s)');
ylabel('$\dot{\psi}$ [rad/s]');

% Segunda figura
figure;

subplot(3,1,1);
plot(t, omega_rpm,'Color',dark_purple);
title('Velocidad angular $\omega$(t) (rpm)');
xlabel('Tiempo (s)');
ylabel('$\omega$(t) [rpm]');

subplot(3,1,2);
plot(t, w_actuator,'b');
title('Entrada al actuador w(t)');
xlabel('Tiempo (s)');
ylabel('w(t)');

subplot(3,1,3);
plot(t, error);
title('Error de control');
xlabel('Tiempo (s)');
ylabel('Error(t)');
figure;

hold on;
plot(t, psi_d, '--', 'DisplayName', 'Referencia $\psi_d(t)$');
plot(t, psi_degrees,'r', 'DisplayName', 'Ángulo $\psi(t)$');
title('Ángulo $\psi(t)$ (grados) vs Referencia');
xlabel('Tiempo (s)');
ylabel('$\psi(t)$ [grados]');
legend;
ylim([0 40]);
