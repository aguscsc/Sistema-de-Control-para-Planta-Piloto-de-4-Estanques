%Ejercicio f)
clc
clear
close all

% PERIODO DISCRETO EN MILISEGUNDOS
T=200*10^(-3);

% VECTOR TIEMPO
t=0:T:10; 

% MATRICES DE ESTADO CONTINUAS
A=[0 1 0;-78.872 -1.319 58.814;0 0 -1.515];

B=[0;0.529;0.027];

C=[1 0 0];

D=[0];

I=[1 0 0;0 1 0;0 0 1]; %matriz identidad de 3x3

% MATRICES DE ESTADO DISCRETAS
Ad=expm(A*T);

Bd=(Ad-I)*(inv(A))*B;

Cd=C;
Cd2=[0 1 0];%para graficar las demas variables de estado se modifica la matriz C
Cd3=[0 0 1];%esa es la gracia de las ecuaciones de estado

Dd=D;

%CREACION DE LA SEÑAL DE REFERENCIA
unitstep1 = t>=1;
ramp1 = (t-1).*unitstep1; %señal rampa desplazada 1 hacia la derecha

unitstep2 = t>=4;
ramp2 = (t-4).*unitstep2; %señal rampa desplazada 4 hacia la derecha

Vio=26.49; %voltaje en estado estacionario
Vid=Vio*(ramp1-ramp2)*(1/3); %señal de voltaje de entrada discreto "u(kT)"

%GRAFICA DE LA REFERENCIA CON SUS SEÑALES RAMPAS QUE LA COMPONEN
figure
stem(t,ramp1,'.') %grafica señal rampa desplazada 1 hacia la derecha
hold on
stem(t,-ramp2,'.') %grafica señal rampa desplazada 4 hacia la derecha
hold on
stem(t,Vid,'.') %grafica señal de voltaje de entrada discreto "u(kT)"
legend('r(kT+T)','-r(kT+4T)','vid')

%FUNCIONES DE TRANSFERENCIA (Z), NUMERADORES Y DENOMINADORES 
[num,den]=ss2tf(Ad,Bd,Cd,Dd); %coeficiendes de H(z)
[num2,den2]=ss2tf(Ad,Bd,Cd2,Dd);
[num3,den3]=ss2tf(Ad,Bd,Cd3,Dd);

%RESPUESTA DE LAS FUNCIONES DE TRANSFERENCIA ANTE UNA ENTRADA Vid
Angulo=filter(num,den,Vid); %respuesta de H(z) ante la entrada Vid
VelocidadAngular1=filter(num2,den2,Vid);
VelocidadAngular2=filter(num3,den3,Vid);

% GRAFICAS 
figure
subplot(4,1,1)
stem(t,Vid,'.g')
title('Entrada vi(kT)')
xlabel('Tiempo (s)')
ylabel('vi(kT) [V]')

subplot(4,1,2)
stem(t,Angulo*(180/pi),'.r')
title('Ángulo$\psi(kT)$ (grados)')
xlabel('Tiempo (s)')
ylabel('ψ(kT) [grados]')

subplot(4,1,3)
stem(t,VelocidadAngular1,'.r')
title('Velocidad angular $\cdot{\psi}(kT)$')
xlabel('Tiempo (s)')
ylabel('$\cdot{\psi}(kT)$ [rad/s]')

subplot(4,1,4)
stem(t,VelocidadAngular2*(60/(2*pi)),'.m') %se le multiplica (60/(2*pi)) para pasarlo a rpm
title('Velocidad angular $\omega$(kT) (rpm)')
xlabel('Tiempo (s)')
ylabel('$\omega$(kT) [rpm]')

%VALORES PROPIOS DEL SISTEMA
ValoresPropiosdeAd=eig(Ad)

% GRAFICA DE POLOS 'X' Y CEROS 'O'
sys = idss(Ad,Bd,Cd,Dd,'Ts',T);
figure
pzmap(sys)